<?php 
$destinatario = "a2wer2ws@hotmail.com"; 
$asunto = "Este mensaje es de prueba"; 
$cuerpo = ' 
<html> 
<head> 
   <title>Prueba de correo</title> 
</head> 
<body> 
<h1>Hola amigos!</h1> 
<p> 
<b>Bienvenidos a mi correo electrónico de prueba</b>. Estoy encantado de tener tantos lectores. Este cuerpo del mensaje es del artículo de envío de mails por PHP. Habría que cambiarlo para poner tu propio cuerpo. Por cierto, cambia también las cabeceras del mensaje. 
</p> 
</body> 
</html> 
'; 

//para el envío en formato HTML 
$headers = "MIME-Version: 1.0\r\n"; 
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 

//dirección del remitente 
$headers .= "From: Miguel Angel Alvarez <jmrs1905@hotmail.com>\r\n"; 

//dirección de respuesta, si queremos que sea distinta que la del remitente 
$headers .= "Reply-To: a2wer2ws@hotmail.com\r\n"; 

//ruta del mensaje desde origen a destino 
$headers .= "Return-path: a2wer2ws@hotmail.com\r\n"; 

//direcciones que recibián copia 
$headers .= "Cc: a2wer2ws@hotmail.com.com\r\n"; 

//direcciones que recibirán copia oculta 
$headers .= "Bcc: jrodriguez@duxstar.com.mx,jmrs1905@hotmail.com.com\r\n"; 

mail($destinatario,$asunto,$cuerpo,$headers) 
?>