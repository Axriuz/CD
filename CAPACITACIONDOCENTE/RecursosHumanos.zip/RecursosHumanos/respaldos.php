<?php 
include("con.php"); 
echo'<title>Restore & backup para windows y linux</title>'; 
echo'<ul><li><a href="respaldo.php">Probar backup de BD</a></li>'; 
//echo'<li><a href="restore.php">Probar restore de BD</a></li></ul>'; 
?>