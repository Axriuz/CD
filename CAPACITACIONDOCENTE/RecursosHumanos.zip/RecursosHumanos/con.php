<?php 
/*error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR); 
$servername="sigacitcg.com.mx"; 
$dbusername="sigacitc"; 
$dbpassword= "Itcg11012016_2"; 
$dbname="sigacitc_cursosdesacadCP"; 

connecttodb($servername,$dbname,$dbusername,$dbpassword); 
function connecttodb($servername,$dbname,$dbusername,$dbpassword) 
{ 
$link=mysql_connect ($servername,$dbusername,$dbpassword); 
if(!$link) 
{ 
die('No puedo Conectarme al Administrador MySQL'.mysql_error()); 
} 
mysql_select_db($dbname,$link) 
or die ('No puedo seleccionar la base de datos'.mysql_error()); 
} */
$host= "sigacitcg.com.mx"; 
$user = "sigacitc"; 
$pass= "Itcg11012016_2"; 

$con=mysqli_connect("$host","$user","$pass","sigacitc_cursosdesacadCP");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit;
}
$bd_seleccionada = mysqli_select_db($con,'sigacitc_cursosdesacadCP');
mysqli_query($con,"SET NAMES UTF8");
?>